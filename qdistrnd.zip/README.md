# gap-package-qdistrnd
GAP package for calculating the distance of a q-ary quantum stabilizer code.
